from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load Model
with open("healthy.pkl", "rb") as file:
    dct_model = pickle.load(file)

print("Model Loaded Successfully")


@app.route("/")
def home():
    return render_template("prediction.html")


@app.route("/predict", methods=["POST"])
def predict():

    gender = request.form["gender"]
    age = float(request.form["age"])
    weight = float(request.form["weight"])
    blood_group = request.form["blood_group"]
    blood_pressure = float(request.form["blood_pressure"])
    haemoglobin = float(request.form["haemoglobin_count"])
    sugar = float(request.form["sugar"])
    platelets = float(request.form["platelets"])
    white_blood_cell = float(request.form["white_blood_cell"])
    red_blood_cell = float(request.form["red_blood_cell"])

    # Encode Gender
    gender_dict = {
        "Male": 1,
        "Female": 0,
        "Other": 2
    }

    # Encode Blood Group
    blood_group_dict = {
        "A+": 0,
        "A-": 1,
        "B+": 2,
        "B-": 3,
        "AB+": 4,
        "AB-": 5,
        "O+": 6,
        "O-": 7
    }

    gender = gender_dict[gender]
    blood_group = blood_group_dict[blood_group]

    data = np.array([[
        gender,
        age,
        weight,
        blood_group,
        blood_pressure,
        haemoglobin,
        sugar,
        platelets,
        white_blood_cell,
        red_blood_cell
    ]])

    prediction = dct_model.predict(data)

    if prediction[0] == 0:
        result = "Healthy"
    else:
        result = "Not Healthy"

    return render_template("result.html", result=result)


if __name__ == "__main__":
    app.run(debug=True)